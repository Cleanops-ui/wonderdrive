
WONDERDRIVE — Pack HTML avec photos

Déploiement : uploadez tout le dossier sur votre hébergeur (OVH, Hostinger, Netlify).
La page d’accueil index.html se chargera automatiquement.

Personnalisation : remplacez les images dans /img/ par vos propres photos en gardant les mêmes noms.
